<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\PurchaseOrder;
use Faker\Generator as Faker;

$factory->define(PurchaseOrder::class, function (Faker $faker) {
    return [
        //
    ];
});
