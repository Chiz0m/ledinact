<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\SerialNumber;
use Faker\Generator as Faker;

$factory->define(SerialNumber::class, function (Faker $faker) {
    return [
        //
    ];
});
